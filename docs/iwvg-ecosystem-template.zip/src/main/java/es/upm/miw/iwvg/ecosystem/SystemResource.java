package es.upm.miw.iwvg.ecosystem;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(SystemResource.SYSTEM)
public class SystemResource {

    public static final String SYSTEM = "/system";

    @Value("${application.name}")
    private String applicationName;

    @Value("${build.version}")
    private String buildVersion;

    @Value("${build.timestamp}")
    private String buildTimestamp;

    @GetMapping
    public String applicationInfo() { // http://localhost:8080/system
        return "Hello World!!! ("
                + this.applicationName + "::" + this.buildVersion + "::" + this.buildTimestamp
                + ")";
    }

}
