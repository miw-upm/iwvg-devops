# Forja
#### Asignatura: *Ingeniería Web: Visión General*
#### [Máster en Ingeniería Web por la U.P.M.](http://miw.etsisi.upm.es)

### Tecnologías necesarias
* Java
* Maven
* Eclipse
* GitHub

### Descripción
Este proyecto pretende ser una plantilla maven para crear un proyecto
1.- Descomprimir en la carpeta de trabajo
1.- Editar el pom.xml y cambiarle el nombre del proyecto
1.- Desde Eclipse, importar el proyecto como un proyecto de maven existente

